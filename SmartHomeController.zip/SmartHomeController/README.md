# SmartHomeController
This project demonstrates how to control different smart devices in Android.

By Charles Xu, 2018-10-10